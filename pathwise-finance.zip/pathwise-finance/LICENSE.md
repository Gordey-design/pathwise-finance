Copyright (c) 2026 Milka. All Rights Reserved.

This software and associated source code (the "Software") are the
proprietary property of the copyright holder.

Permission is granted to view this Software's source code for
educational and portfolio-review purposes only (e.g., as part of a
resume, job application, or learning reference).

No permission is granted to:
- Copy, reproduce, or redistribute this Software, in whole or in part
- Modify or create derivative works based on this Software
- Use this Software, or any portion of it, in any other project,
  commercial or non-commercial
- Publish, host, or deploy a copy of this Software under a different
  name or branding

without prior express written permission from the copyright holder.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY CLAIM,
DAMAGES, OR OTHER LIABILITY ARISING FROM THE USE OF THE SOFTWARE.

Pathwise Finance is an educational financial planning tool and does
not constitute financial, tax, or legal advice.
