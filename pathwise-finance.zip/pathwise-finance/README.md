# Pathwise Finance

A single-page personal financial planning tool built with vanilla
HTML, CSS, and JavaScript — no frameworks, no build step, no
backend. Open `index.html` in any browser and it runs.

## What it does

Pathwise Finance helps people allocate a paycheck across savings,
investments, and expenses, with guidance tailored to 15 different
life situations:

- Single, Married, Family (with dedicated childcare allocation),
  Near-retirement, Student, Military, Veteran, Government employee,
  Teacher
- Wealth-building tracks: Real Estate, Business/Entrepreneurship,
  Collectibles & alternative investments, Stocks & sectors, HYSA & CDs

For each situation it provides:

- **Smart default allocations** (adjustable via sliders, 0–85%)
- **Federal + state tax estimates** for 2026 brackets
- **A dedicated Tax Incentives tab** listing the specific deductions,
  credits, and strategies relevant to that group (e.g. PSLF for
  teachers/government, combat-zone pay exclusion for military, REPS
  and 1031 exchanges for real estate investors)
- **Live market ticker** (Dow, S&P 500, Nasdaq, Russell 2000, VIX,
  and individual stocks) via a Yahoo Finance proxy
- **Multi-profile support** for households with more than one income
- **10+ visual themes**, including solid color/high-contrast options
- **Local account system** — username/password stored hashed in
  `localStorage`, no server or external accounts required

## Tech notes

- Single HTML file (~220KB), self-contained except for Chart.js (CDN)
  and a market-data proxy fetch
- All persistence via `localStorage` — nothing leaves the browser
  except the optional market data fetch
- Built with accessibility in mind: ARIA roles on tabs, focus-visible
  styles, `prefers-reduced-motion` support, screen-reader labels on
  sliders and ticker chips

## Disclaimer

This tool is for educational purposes only and does not constitute
financial, tax, or legal advice. Tax figures are estimates based on
published 2026 brackets and may not reflect your specific situation.
Consult a qualified professional for advice.

## License

See [LICENSE.md](LICENSE.md). All rights reserved — source code is
shared for portfolio/review purposes only.
